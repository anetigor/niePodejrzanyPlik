<?php

function transformuj($xmlFile, $xslFile) {
    $xml = new DOMDocument();
    $xml->load($xmlFile);
    $xsl = new DOMDocument();
    $xsl->load($xslFile);
    $proc = new XSLTProcessor();
    $proc->importStyleSheet($xsl);
    echo $proc->transformToXML($xml);
}

if (isset($_GET['widok'])) {
    if ($_GET['widok'] == 'lista') {
        transformuj('Baza.xml', 'lista.xsl');
        exit; 
    } elseif ($_GET['widok'] == 'pelny') {
        transformuj('Baza.xml', 'Widok.xsl');
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
</head>
<body>

<div style="background: #eee; padding: 10px;">
    <a href="?widok=lista"><button>Widok: Lista (4j)</button></a>
    <a href="?widok=pelny"><button>Widok: Relacja (4k)</button></a>
    <a href="index.php"><button>Powrót do Filtra</button></a>
</div>

<hr>

<?php
$xml = simplexml_load_file('Baza.xml');
$filtr = isset($_GET['stanowisko']) ? $_GET['stanowisko'] : 's1'; 

// Pobranie nazwy stanowiska do nagłówka [cite: 1, 2]
$nazwa_st = $xml->xpath("//stanowisko[@id='$filtr']/nazwa")[0];
echo "<h2>Pracownicy na stanowisku: " . $nazwa_st . "</h2>";
?>

<form method="GET">
    <select name="stanowisko">
        <?php
        foreach ($xml->stanowiska->stanowisko as $st) {
            $id = (string)$st['id'];
            $txt = (string)$st->nazwa;
            $sel = ($id == $filtr) ? 'selected' : '';
            echo "<option value='$id' $sel>$txt</option>";
        }
        ?>
    </select>
    <input type="submit" value="Filtruj">
</form>

<table border="1" style="margin-top: 10px;">
    <tr><th>Nazwisko</th><th>Imie</th></tr>
    <?php
    foreach ($xml->zatrudnienie->wpis as $wpis) {
        if ((string)$wpis['id_stanowiska'] === $filtr) {
            $p_id = (string)$wpis['id_pracownika'];
            // Wyszukanie pracownika w tabeli pracownicy [cite: 3, 4]
            $pracownik = $xml->xpath("//pracownik[@id='$p_id']")[0];
            echo "<tr><td>{$pracownik->nazwisko}</td><td>{$pracownik->imie}</td></tr>";
        }
    }
    ?>
</table>

</body>
</html>