<?php
session_start();
$config = include 'config.php';
$dir = $config['messages_dir'];

$logged = isset($_SESSION['logged']) && $_SESSION['logged'] === true;

$files = [];
if (is_dir($dir)) {
    $files = array_filter(scandir($dir), fn($f) => $f !== '.' && $f !== '..');
    usort($files, fn($a, $b) => filemtime($dir . $b) <=> filemtime($dir . $a));
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>pskVlog - Wiadomości</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>pskVlog</header>

<nav>
    <a href="index.php">Wiadomości</a> <?php if (!$logged): ?>
        <a href="login.php">Zaloguj</a> <?php else: ?>
        <a href="a1.php">Panel Admina</a>
        <a href="logout.php">Wyloguj</a>
    <?php endif; ?>
</nav>

<div class="container">

    <h2>Wiadomości</h2>

    <?php if (empty($files)): ?>
        <p><b>Brak wiadomości.</b></p>
    <?php else: ?>

        <?php foreach ($files as $file): ?>
            <?php
                $path = $dir . basename($file);
                $raw = file_get_contents($path);
                $lines = explode("\n", $raw, 4);

                $title = trim(str_replace("Tytuł:", "", $lines[0] ?? ""));
                $date  = trim(str_replace("Data:", "", $lines[1] ?? ""));
                $content = $lines[3] ?? "";
            ?>

            <div class="msg">
                <div class="msg-title"><?= htmlspecialchars($title) ?></div>
                <div class="msg-date"><?= htmlspecialchars($date) ?></div>
                <div><?= nl2br(htmlspecialchars($content)) ?></div>
                </div>

        <?php endforeach; ?>

    <?php endif; ?>

</div>

</body>
</html>