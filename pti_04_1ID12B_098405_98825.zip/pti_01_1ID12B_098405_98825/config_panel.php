<?php
$config = include 'config.php'; 
?>

<h2>Panel Konfiguracji</h2>

<form action="update.php" method="post">
    <h3>Ścieżka dodawania plików</h3>
    <p>Aktualna ścieżka: <code><?= htmlspecialchars($config['messages_dir']) ?></code></p>
    <label for="messages_dir">Nowa ścieżka (pozostaw puste, aby nie zmieniać):</label>
    <input type="text" id="messages_dir" name="messages_dir" placeholder="<?= htmlspecialchars($config['messages_dir']) ?>">
    <p style="font-size: 12px; color: gray;">Pamiętaj o ukośniku na końcu, np. <code>messages/</code></p>

    <h3>Zmiana danych logowania</h3>
    <label for="username">Nowa nazwa użytkownika (pozostaw puste, aby nie zmieniać):</label>
    <input type="text" id="username" name="username" placeholder="<?= htmlspecialchars($config['username']) ?>">

    <label for="password">Nowe hasło administratora (pozostaw puste, aby nie zmieniać):</label>
    <input type="password" id="password" name="password">

    <?php
    // Pobieranie i wyświetlanie komunikatu o sukcesie
    if (isset($_SESSION['success_message'])):
    ?>
        <p style="color: green; font-weight: bold; margin-top: 15px;">
            <?= htmlspecialchars($_SESSION['success_message']) ?>
        </p>
    <?php
        // Usuwamy komunikat, aby nie wyświetlał się ponownie po odświeżeniu
        unset($_SESSION['success_message']);
    endif;
    ?>
    <p><button type="submit">Zapisz Konfigurację</button></p>
</form>