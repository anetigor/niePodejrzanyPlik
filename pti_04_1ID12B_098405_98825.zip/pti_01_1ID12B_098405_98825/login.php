<?php
session_start();
$config = include 'config.php';
$error = '';

if (isset($_POST['username'], $_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $config['username'] && $password === $config['password']) {
        $_SESSION['logged'] = true;
        header('Location: a1.php');
        exit;
    } else {
        $error = 'Błędna nazwa użytkownika lub hasło.';
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Logowanie - pskVlog</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>pskVlog</header>

<div class="container">
    <div class="login-form">
        <h2>Panel Logowania</h2>
        <?php if ($error): ?>
            <p style="color: red; text-align: center;"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form action="login.php" method="post">
            <label for="username">Nazwa użytkownika:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Hasło:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Zaloguj</button>
        </form>
    </div>
</div>

</body>
</html>