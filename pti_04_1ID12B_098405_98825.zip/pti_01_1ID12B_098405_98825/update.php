<?php
// update.php
session_start();
$config = include 'config.php';

if (!isset($_SESSION['logged']) || $_SESSION['logged'] !== true) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $messages_dir = trim($_POST['messages_dir'] ?? '');
    if ($messages_dir === '') $messages_dir = $config['messages_dir'];
    
    $messages_dir = str_replace('\\', '/', $messages_dir);
    if (substr($messages_dir, -1) !== '/') $messages_dir .= '/';

    $username = trim($_POST['username'] ?? '');
    if ($username === '') $username = $config['username'];

    $password = $_POST['password'] ?? '';
    $newPassword = ($password !== '') ? $password : $config['password'];


    $newConfig = "<?php\nreturn [\n"
        . " 'messages_dir' => '" . addslashes($messages_dir) . "',\n"
        . " 'username' => '" . addslashes($username) . "',\n"
        . " 'password' => '" . addslashes($newPassword) . "',\n"
        . "];";

    if (is_writable('config.php')) {
        file_put_contents('config.php', $newConfig);
        header('Location: a1.php?mode=config');
        exit;
    } else {
        die('Błąd: Brak uprawnień do zapisu pliku config.php. Zmień uprawnienia.');
    }
}

header('Location: a1.php');
exit;