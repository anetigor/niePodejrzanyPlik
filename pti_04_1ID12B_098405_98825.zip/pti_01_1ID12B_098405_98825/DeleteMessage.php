<?php
session_start();
$config = include 'config.php';
if (!isset($_SESSION['logged']) || $_SESSION['logged'] !== true) {
header('Location: login.php');
exit;
}
$dir = $config['messages_dir'];
$file = $_GET['file'] ?? '';
if ($file === '' || strpos($file, '..') !== false || strpos($file, '/') !== false || strpos($file, "\\") !== false) {
die('Nieprawidłowy plik.');
}
$path = $dir . $file;
if (is_file($path)) {
unlink($path);
}
header('Location: a1.php');
exit;