<?php
return [
 'messages_dir' => 'C:/xampp/htdocs/pti_01_1ID12B_098405_98825/messages/',
 'username' => 'admin',
 'password' => '12345',
];