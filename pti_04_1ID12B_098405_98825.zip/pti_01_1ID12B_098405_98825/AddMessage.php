<?php
session_start();
$config = include 'config.php';
if (!isset($_SESSION['logged']) || $_SESSION['logged'] !== true) {
header('Location: login.php');
exit;
}
$dir = $config['messages_dir'];
if (!is_dir($dir)) mkdir($dir, 0755, true);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$title = trim($_POST['title'] ?? '');
$content = trim($_POST['content'] ?? '');
if ($content === '') {
die('Pusta treść.');
}
$safeTitle = preg_replace('/[^a-zA-Z0-9-_]/', '_', mb_substr($title,0,50));
$filename = time() . '_' . $safeTitle . '_' . uniqid() . '.txt';
$full = $dir . $filename;
$data = "Tytuł: $title\nData: " . date('Y-m-d H:i:s') . "\n\n" . $content;
file_put_contents($full, $data);
header('Location: a1.php');
exit;
}
header('Location: a1.php');
exit;