<?php
session_start();
$config = include 'config.php';
$dir = $config['messages_dir'];

if (!isset($_SESSION['logged']) || $_SESSION['logged'] !== true) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file_name = $_POST['file'] ?? null;
    $new_title = trim($_POST['title'] ?? '');
    $new_content = $_POST['content'] ?? '';

    if (!$file_name || empty($new_title)) {
        die('Błąd: Brak nazwy pliku lub tytułu.');
    }

    $path = $dir . basename($file_name);

    if (!file_exists($path)) {
        die('Błąd: Plik wiadomości nie istnieje.');
    }

    $raw_original = file_get_contents($path);
    $lines = explode("\n", $raw_original, 4);

    $date_line = $lines[1] ?? 'Data: Nieznana';

    $new_file_content = "Tytuł: " . $new_title . "\n"
                      . $date_line . "\n" 
                      . "\n" 
                      . $new_content;
    if (file_put_contents($path, $new_file_content) !== false) {
        header('Location: a1.php');
        exit;
    } else {
        die('Błąd zapisu pliku. Sprawdź uprawnienia do folderu: ' . $dir);
    }
}

header('Location: a1.php');
exit;