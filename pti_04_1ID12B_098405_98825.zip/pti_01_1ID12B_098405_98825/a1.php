
<?php
session_start();
$config = include 'config.php';
$dir = $config['messages_dir'];

if (!isset($_SESSION['logged']) || $_SESSION['logged'] !== true) {
    header('Location: index.php');
    exit;
}

$mode = $_GET['mode'] ?? 'list';

$files = [];
if (is_dir($dir)) {
    $files = array_filter(scandir($dir), fn($f) => $f !== '.' && $f !== '..');
    usort($files, fn($a, $b) => filemtime($dir . $b) <=> filemtime($dir . $a));
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>pskVlog - Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>pskVlog - Panel Administracyjny</header>

<nav>
    <a href="index.php">Wyświetl wiadomości (Publiczny widok)</a>
    <a href="a1.php?mode=list">Wiadomości (Admin)</a>
    <a href="a1.php?mode=add">Dodaj wiadomość</a>
    <a href="a1.php?mode=config">Konfiguracja</a> 
    <a href="logout.php">Wyloguj</a>
</nav>

<div class="container">

    <?php
    if ($mode === 'add'):
    ?>
        <h2>Dodaj nową wiadomość</h2>
        <form action="addMessage.php" method="post">
            <p>Tytuł:</p>
            <input type="text" name="title" required>

            <p>Treść:</p>
            <textarea name="content" required></textarea>

            <p><button type="submit">Zapisz</button></p>
        </form>

    <?php elseif ($mode === 'edit'):
        $file_to_edit = $_GET['file'] ?? null;
        $path = $dir . basename($file_to_edit);
        $title = '';
        $content = '';

        if ($file_to_edit && file_exists($path)) {
            $raw = file_get_contents($path);
            $lines = explode("\n", $raw, 4);
            $title = trim(str_replace("Tytuł:", "", $lines[0] ?? ""));
            $content = $lines[3] ?? "";
        } else {
            echo '<p style="color:red;">Błąd: Nie znaleziono pliku do edycji.</p>';
            $file_to_edit = '';
        }
    ?>

        <h2>Edytuj wiadomość: <?= htmlspecialchars($title) ?></h2>
        <form action="updateMessage.php" method="post">
            <input type="hidden" name="file" value="<?= htmlspecialchars($file_to_edit) ?>">

            <p>Tytuł:</p>
            <input type="text" name="title" value="<?= htmlspecialchars($title) ?>" required>

            <p>Treść:</p>
            <textarea name="content" required><?= htmlspecialchars($content) ?></textarea>

            <p><button type="submit">Zapisz Zmiany</button></p>
        </form>

    <?php elseif ($mode === 'config'):
        include 'config_panel.php';
    ?>
    
    <?php
    
    else:
    ?>

        <h2>Lista Wiadomości (Admin)</h2>

        <?php if (empty($files)): ?>
            <p><b>Brak wiadomości.</b></p>
        <?php else: ?>

            <?php foreach ($files as $file): ?>
                <?php
                    $path = $dir . basename($file);
                    $raw = file_get_contents($path);
                    $lines = explode("\n", $raw, 4);

                    $title = trim(str_replace("Tytuł:", "", $lines[0] ?? ""));
                    $date  = trim(str_replace("Data:", "", $lines[1] ?? ""));
                    $content = $lines[3] ?? "";
                ?>

                <div class="msg">
                    <div class="msg-title"><?= htmlspecialchars($title) ?></div>
                    <div class="msg-date"><?= htmlspecialchars($date) ?></div>
                    <div><?= nl2br(htmlspecialchars($content)) ?></div>

                    <div class="controls">
                        <a href="DeleteMessage.php?file=<?= urlencode($file) ?>"
                           onclick="return confirm('Na pewno chcesz usunąć?')">
                             Usuń
                        </a>
                        <a href="a1.php?mode=edit&file=<?= urlencode($file) ?>">Edytuj</a>
                    </div>
                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    <?php endif; ?>

</div>

</body>
</html>